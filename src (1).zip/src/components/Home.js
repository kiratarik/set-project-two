function Home() {
  return (
    <section className="section">
      <h1 className='title is-1' id='title'>Diction-Airy</h1>
    </section>
    
  )
}

export default Home